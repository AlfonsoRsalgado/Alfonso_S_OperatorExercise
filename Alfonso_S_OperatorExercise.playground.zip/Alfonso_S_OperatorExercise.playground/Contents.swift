import Cocoa

var greeting = "Hello, playground"
// in-put of variables (N=Numbers)
var N1 = 262
var N2 = 56
//Opperations
var add = N1 + N2
var subtract = N1 - N2
var multiply = N1 * N2
var divide = N1 / N2
//Solving
print ("\(N1) + \(N2) = \(add)")
print ("\(N1) - \(N2) = \(subtract)")
print ("\(N1) * \(N2) = \(multiply)")
print ("\(N1) / \(N2) = \(divide)")
